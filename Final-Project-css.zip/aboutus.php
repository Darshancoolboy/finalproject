<!DOCTYPE html>
<html lang="en">
  <head>
    <title>About us</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        	<link rel="shortcut icon" href="images/Icon.jpg" type="image/x-icon" />
    <link href="css/styles.css" rel="stylesheet">
  </head>
  <body>

     <div class="logo_container">
      <div class="title_container">
      <img src="../images/Logo.jpg"  class="main_logo">
      <h1 class="main_title">Book Library</h1>
      </div>
      <div>
      <ul class="nav_links">
              <li ><a href="index.php" >Home</a></li>
            <li style="margin-left:30px"><a href="support.php">Support</a></li>
<!--         <li style="margin-left:30px"><a href="aboutus.php">About Us</a></li> -->
      
            </ul>
      </div>
      </div>

    
<div style="margin-top:50px">
       <h1 style="color:#8f1d14; ">Who We Are?</h1>
  </div>
    
    <div style="margin-top:50px;">
        <h2 style="color:#50717b; margin-bottom:20px">Canada's destination for buying various type of Books Bunch </h2>
        <p style="font-size:large; color:black; ">
            For more than 27 years, Book Library has been the trusted brand to buy various types of Books all over canada. We have generated revenue of over $2 billion and still increasing it on daily basis.

        </p>
      </div>

    <div style="margin-bottom:50px">
        <h2 style="color:#50717b; margin-top:50px;margin-bottom:20px ">Our Registered Address</h2>
        <p style="font-size:large; color:black ">120 Industry Street, Unit C, Toronto, ON, M6M 4L8</p>
    </div>

      <div style="display: flex;flex-direction:row;margin-top:50px">
            <div style="width:50%;display:flex;align-items:center;justify-content:center">
                <img class="" src="images/lock_mission.png" style="width:200px;height:200px">
            </div>
            <div style="width:50%">
                <h2 style="color:#0070AE; margin-top:50px ;margin-bottom:20px">Our Mission</h2>
                <p style="font-size:large; color:black">
                    Our mission is to provide quality but affordable books for education, entertainment, self-development and self-fulfillment.
                </p>
            </div>
        </div>

     <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:50%;display:flex;align-items:center;justify-content:center">
                <img class="" src="images/lock_vision.png" style="width:200px;height:200px">

            </div>
            <div style="width:50%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                    Our Vision
                </h2>
                <p style="font-size:large; color:black">
                  Our vision is to become the largest and leading book distributor in North America and to be the bookselling household name in the North America Sub Region.
                </p>
            </div>
        </div>


<!--      <img src="images/about4.jpg" alt="lock with girl"  style="width:100%;height:800px" > -->
    
<div style="margin-top:50px;margin-bottom:100px">
 
 

   <p style="font-size:25px; color:black">
                 We hope you enjoy the site, and please let us know your valuable feedback to us by <a href="form.php"> Clicking here</a>
                </p>

  </div>
  </body>
</html>
