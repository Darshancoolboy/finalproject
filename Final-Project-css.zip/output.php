<!DOCTYPE html>
<html lang="en">
  <div class="output">
	<head>
		<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="shortcut icon" href="images/icon.jpg" type="image/x-icon"/>
		<title>Feedback</title>
    <link href="css/styles.css" rel="stylesheet">
    
	</head> 
	<body>
<?php
$name = $_GET['name'];

  echo('Thank you, '.$name.' for rating us.');
?>
  </br>
<img src="images/tickmark.jpg" alt=tickmark height="10%" width="10%">
</body>
    </div>
</html>

