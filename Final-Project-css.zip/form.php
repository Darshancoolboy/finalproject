  <!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Feedback</title>
   <link rel="stylesheet" href="css/styles.css" type="text/css" />
    	<link rel="shortcut icon" href="images/icon.jpg" type="image/x-icon" />
	</head>

	<body>
   
 <div class="form-container">
          <form action="output.php" method="get">
            
            <h1>Give Your Feedback</h1>
        <label for="name">Name</label>
<input type="text" placeholder="name" id="name" name="name" required/>
            
             <label for="email">E-mail</label>
            <input type="text" placeholder="e-mail" id="email" name="email" required/>
            
             <label for="feedback">Your Message</label>
            <textarea name="feedback" id="feedback" name="feedback" cols="20" rows="8" placeholder="Your message" required></textarea>
          </br>
            <div class="rating">
            <label>Ratings</label>
            </div>
            <div class="rate">
    <input type="radio" id="star5" name="rate" value="5" />
    <label for="star5" title="text">5 stars</label>
    <input type="radio" id="star4" name="rate" value="4" />
    <label for="star4" title="text">4 stars</label>
    <input type="radio" id="star3" name="rate" value="3" />
    <label for="star3" title="text">3 stars</label>
    <input type="radio" id="star2" name="rate" value="2" />
    <label for="star2" title="text">2 stars</label>
    <input type="radio" id="star1" name="rate" value="1" />
    <label for="star1" title="text">1 star</label>
  </div>
            <footer>  
            <button type="submit">Submit</button>
              </footer>
                      </form>
        </div>
	</body>
      
</html>

