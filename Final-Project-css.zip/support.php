<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Support</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="shortcut icon" href="images/Icon.jpg" type="image/x-icon" />
    <link href="css/styles.css" rel="stylesheet">
  </head>
  <body>

     <div class="logo_container">
      <div class="title_container">
      <img src="../images/Logo.jpg"  class="main_logo">
      <h1 class="main_title">Book Library</h1>
      </div>
      <div>
      <ul class="nav_links">
              <li ><a href="index.php" >Home</a></li>
<!--             <li style="margin-left:30px"><a href="support.php">Support</a></li> -->
        <li style="margin-left:30px"><a href="aboutus.php">About Us</a></li>
      
            </ul>
      </div>
      </div>

    
    <div style="margin-top:100px;display:flex;flex-direction:row;justify-content:center">
      <p style="font-size:50px">We've got your back</p>
    </div>

    <div style="margin-top:50px;display:flex;flex-direction:row;justify-content:center">
      <p style="font-size:30px">Can't find what you need? Get in touch with our friendly Team</p>
    </div>

<div style="display:flex;margin-top:80px;margin-bottom:80px;justify-content:center">
    <img src="images/team-icon.jpeg" style="width:90%;height:400px">
  </div>

    

    
    <div style="margin-bottom:50px;">
   <div style="display:flex;justify-content:center">
<h2 style="margin-bottom:20px;color:#0070AE">Our Operation Hour:</h2>
   </div>

      
      
     <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Monday :</p> </div> 
       <div> <p>9 am - 5 pm </p></div>
       </div><br>
       <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Tuesday :</p> </div> 
       <div> <p>9 am - 5 pm </p></div>
       </div><br>
       <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Wednesday :</p> </div> 
       <div> <p>9 am - 5 pm </p></div>
       </div><br>
       <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Thursday :</p> </div> 
       <div> <p>9 am - 5 pm </p></div>
       </div><br>
       <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Friday :</p> </div> 
       <div> <p>9 am - 5 pm </p></div>
       </div> <br>
      
      <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Saturday :</p> </div> 
       <div> <p> Close</p></div>
       </div><br>
 <div style="display:flex;justify-content:center">
       <div style="margin-right:15px"><p style="font-weight:bold">Sunday :</p> </div> 
       <div> <p> Colse</p></div>
       </div><br>
      
    </div>  

       <div style="display: flex;flex-direction:row;margin-top:50px">
            <div style="width:50%;display:flex;align-items:center;justify-content:center">
                <img class="" src="images/phone.png" style="width:200px;height:200px">
            </div>
            <div style="width:50%">
                <h2 style="color:#0070AE; margin-top:50px ;margin-bottom:20px">Call us</h2>
                <p style="font-size:large; color:black">
                    +1 437-422-7201
                </p>
            </div>
        </div>
      
    
      
    
  

 <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:50%;display:flex;align-items:center;justify-content:center">
                <img class="" src="images/email.jpg" style="width:300px;height:200px">

            </div>
            <div style="width:50%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                    Email
                </h2>
                <p style="font-size:large; color:black">
                 Feel free to send us an email <a href="">booklibrary1995@gmail.com</a> 
                </p>
            </div>
 </div>



 <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:50%;display:flex;align-items:center;justify-content:center">
                <img class="" src="images/social_media.png" style="width:200px;height:200px">

            </div>
            <div style="width:50%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                    Social Media
                </h2>
                <p style="font-size:large; color:black">
                 <ul  style="list-style:none;">
<li><a href="">Facebook</a></li>
<li><a href="">Twitter</a></li>
<li><a href="">Instagram</a></li>
</ul>
                </p>
            </div>

 </div>


   <div style="margin-bottom:80px;margin-top:50px" >
     <p style="font-size:20px">
Our Customer Service teams are working hard to help you. Please note, we are experiencing longer delivery times due to extra safety precautions being taken at our warehouse. Thank you for your patience.</p>
      </div>
