<!DOCTYPE html>
<html lang="en">
  <head>
    <title>promotion details</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="shortcut icon" href="images/Icon.jpg" type="image/x-icon" />
    <link href="css/styles.css" rel="stylesheet">
  </head>
  <body>
      <div class="logo_container">
      <div class="title_container">
      <img src="../images/Logo.jpg"  class="main_logo">
      <h1 class="main_title">Book Library</h1>
      </div>
      <div>
      <ul class="nav_links">
              <li ><a href="index.php" >Home</a></li>
            <li style="margin-left:30px"><a href="support.php">Support</a></li>
<!--         <li style="margin-left:30px"><a href="aboutus.php">About Us</a></li> -->
      
            </ul>
      </div>
      </div>

    <script>
function myFunctiondeals() {
  alert("Thank-you! Bulk deal applied for books!");
}
</script>
    <script>
function myFunctionshipping() {
  alert("Congratulations! you got the free-delivery for product!");
}
</script>
    <script>
function myFunctionLimited() {
  alert("Here are some unique books!");
}
</script>
    <script>
function myFunctionEducation() {
  alert("Here are free educational materials about the history of ancient books!");
}
</script>
    <script>
function myFunctionDiscount() {
  alert("woho! Get the best deal with our latest coupon codes. Save Big.!");
}
</script>

    <div style="display:flex;justify-content:center;margin-top:30px">
    
     <div class="card">
   <div class="des">
                    <div style="margin-top:20px;">
                        <h3> Free Shipping</h3>
                      <p style="margin-top:20px">Offer free shipping for online purchases of any book to make them more accessible to customers who live far away.</p>
                    </div>
                    <div style="margin-bottom:20px">
                        <button class="card_button" onclick="myFunctionshipping()" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>
  <div class="card">
   <div class="des">
                    <div style="margin-top:20px;">
                        <h3> Educational materials</h3>
                      <p style="margin-top:20px">Offer free educational materials, such as brochures or videos, that explain the history and significance of each book. </p>
                    </div>
                    <div style="margin-bottom:20px">
                        <button class="card_button" onclick="myFunctionEducation()" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

  </div>
      <div class="card">
   <div class="des">
                    <div style="margin-top:20px;">
                        <h3> Limited edition</h3>
                      <p style="margin-top:20px">Offer a limited edition run of some best selling books that are unique and not replicated, making them highly sought after.

</p>
                    </div>
                    <div style="margin-bottom:20px">
                        <button class="card_button" onclick="myFunctionLimited()" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>

    </div>


    <div style="display:flex;justify-content:center;margin-bottom:80px;margin-top:">

      

       <div class="card">
   <div class="des">
                    <div style="margin-top:20px;">
                        <h3> Discounts</h3>
                      <p style="margin-top:20px">Offer limited-time discounts or promotions to incentivize customers to purchase limited edition books.</p>
                    </div>
                    <div style="margin-bottom:20px">
                        <button class="card_button" onclick="myFunctionDiscount()" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>
    
    <div class="card">
  
                    
     <div class="des">
                    <div style="margin-top:20px;">
                        <h3>Bundled Deals</h3>
                      <p style="margin-top:20px">Offer discounts for purchasing sets of books, encouraging collectors to purchase multiple books at once.
</p>
                    </div>
                    <div style="margin-bottom:20px">
                        <button class="card_button" onclick="myFunctiondeals()"  style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>
      
   
</div>
 

