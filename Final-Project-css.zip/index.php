<!DOCTYPE html>
<html lang="en">
  <head>
    <title>The Book Dashboard</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<link rel="shortcut icon" href="images/Icon.jpg" type="image/x-icon" />
    <link href="css/styles.css" rel="stylesheet">
  </head>
  <body>
    
    <div class="logo_container">
      <div class="title_container">
      <img src="../images/Logo.jpg"  class="main_logo">
      <h1 class="main_title">Book Library</h1>
      </div>
      <div>
      <ul class="nav_links">
              <li ><a href="index.php" >Home</a></li>
            <li style="margin-left:30px"><a href="support.php">Support</a></li>
        <li style="margin-left:30px"><a href="aboutus.php">About Us</a></li>
      
            </ul>
      </div>
      </div>
   
    
    <div class="main_heading">
        <h1>Place where you will find all types of books.</h1>
    </div>

    <div style="display:flex;flex-direction:row;justify-content:center">

      
   <div class="card">
  <div class="image">
    <img class="card_logo" src="images/promotion.jpeg" alt="promotion">
  </div>
                    
     <div class="des">
                    <div>
                        <h3> Promtotion Details</h3>
                    </div>
                    <div>
                        <button class="card_button" onclick="window.location.href='promotion.php'" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>


      
      <div class="card">
  <div class="image">
    <img class="card_logo" src="images/product.jpg" alt="produ">
  </div>
                    
     <div class="des">
                    <div>
                        <h3> Product Details</h3>
                    </div>
                    <div>
                        <button class="card_button" onclick="window.location.href='productdesc.php'" style="width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>


       <div class="card">
  <div class="image">
    <img class="card_logo" src="images/feedback.jpeg" alt="vlok 1">
  </div>
                    
     <div class="des">
                    <div>
                        <h3> Feedback</h3>
                    </div>
                    <div>
                        <button class="card_button" onclick="window.location.href='form.php'" style="margin-bottom:50px;width:80px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">View</button>
                    </div>
                </div>

</div>


      
    </div>  
      
     <footer style="margin-top:80px">
        <p>&copy; Vintage Locks Pvt. Ltd. 1999-2023</p>
    </footer>

  </body>
</html>