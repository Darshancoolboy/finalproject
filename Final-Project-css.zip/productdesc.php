<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Product details</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        	<link rel="shortcut icon" href="images/Icon.jpg" type="image/x-icon" />
    <link href="css/styles.css" rel="stylesheet">
  </head>
  <body>

     <div class="logo_container">
      <div class="title_container">
      <img src="../images/Logo.jpg"  class="main_logo">
      <h1 class="main_title">Book Library</h1>
      </div>
      <div>
      <ul class="nav_links">
              <li ><a href="index.php" >Home</a></li>
            <li style="margin-left:30px"><a href="support.php">Support</a></li>
        <li style="margin-left:30px"><a href="aboutus.php">About Us</a></li>
      
            </ul>
      </div>
      </div>

      <script>
function myFunctionAntique() {
  alert("Historical Fiction Books is added in your cart!");
}
      </script>
    
    <script>
      function myFunctionCombination() {
  alert("Mystery books is added in your cart!");
}</script>    

            <script>
            function myFunctionTibetan() {
  alert("Fantasy books is added in your cart!");
}
</script>

        <script>
            function myFunctionRim() {
  alert("Comic Books is added in your cart!");
}
</script>
    <script>
            function myFunctionPad() {
  alert("Children's Literature Books is added in your cart!");
}
</script>

 <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:40%;display:flex;align-items:center;justify-content:center;border-radius:">
               
 <img src="images/Ancient.jpg" alt="vlok 1"style="width:300px;height:300px">
            </div>
            <div style="width:60%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                    Historical Fiction
                </h2>
                <p style="font-size:large; color:black">
                 The history of books became an acknowledged academic discipline in the 1980s. Contributors to the discipline include specialists from the fields of textual scholarship, codicology, bibliography, philology, palaeography, art history, social history and cultural history. Its key purpose is to demonstrate that the book as an object, not just the text contained within it, is a conduit of interaction between readers and words.
                </p>
               <button class="card_button" onclick="myFunctionAntique()" style="width:130px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">Add to cart</button>
            </div>
        </div>

  


     <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:40%;display:flex;align-items:center;justify-content:center">
               
 <img src="images/mystery.jpg" alt="vlok 1"style="width:300px;height:300px">
            </div>
            <div style="width:60%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                   Mystery
                </h2>
                <p style="font-size:large; color:black">
                Mystery is a fiction genre where the nature of an event, usually a murder or other crime, remains mysterious until the end of the story. Often within a closed circle of suspects, each suspect is usually provided with a credible motive and a reasonable opportunity for committing the crime. The central character is often a detective (such as Sherlock Holmes), who eventually solves the mystery by logical deduction from facts presented to the reader. Some mystery books are non-fiction. Mystery fiction can be detective stories in which the emphasis is on the puzzle or suspense element and its logical solution such as a whodunit. Mystery fiction can be contrasted with hardboiled detective stories, which focus on action and gritty realism.
                </p>
              <div style="margin-top:10px;display:flex;flex-direction:row;align-content:center"><p style="font-size:20px;font-weight:bold">Price  -  </p> <p style="font-size:20px;margin-left:10px">$ 50.0</p></div>
               <button class="card_button" onclick="myFunctionCombination()" style="width:130px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">Add to cart</button>
            </div>
        </div>


     <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:40%;display:flex;align-items:center;justify-content:center">
               
 <img src="images/fantasy.jpg" alt="vlok 1"style="width:300px;height:300px">
            </div>
            <div style="width:60%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                   Fantasy
                </h2>
                <p style="font-size:large; color:black">
               Fantasy literature is literature set in an imaginary universe, often but not always without any locations, events, or people from the real world. Magic, the supernatural and magical creatures are common in many of these imaginary worlds. Fantasy literature may be directed at both children and adults.
                </p>
               <button class="card_button" onclick="myFunctionTibetan()" style="width:130px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">Add to cart</button>
            </div>
        </div>


     <div style="display: flex;flex-direction:row;margin-top:100px">
            <div style="width:40%;display:flex;align-items:center;justify-content:center">
               
 <img src="images/comic.jpg" alt="vlok 1"style="width:300px;height:300px">
            </div>
            <div style="width:60%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                   Comics
                </h2>
                <p style="font-size:large; color:black">
               A comic book, also called comicbook, comic magazine or (in the United Kingdom and Ireland) simply comic, is a publication that consists of comics art in the form of sequential juxtaposed panels that represent individual scenes. Panels are often accompanied by descriptive prose and written narrative, usually, dialogue contained in word balloons emblematic of the comics art form.
                </p>
               <button class="card_button" onclick="myFunctionRim()" style="width:130px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">Add to cart</button>
            </div>
        </div>

     <div style="display: flex;flex-direction:row;margin-top:100px;margin-bottom:100px">
            <div style="width:40%;display:flex;align-items:center;justify-content:center">
               
 <img src="images/children.jpg" alt="vlok 1"style="width:300px;height:300px">
            </div>
            <div style="width:60%">
                <h2 style="color:#0070AE; margin-top:50px;margin-bottom:20px ">
                   Children's Literature
                </h2>
                <p style="font-size:large; color:black">
              Children's literature or juvenile literature includes stories, books, magazines, and poems that are created for children. Modern children's literature is classified in two different ways: genre or the intended age of the reader, from picture books for the very young to young adult fiction.
                </p>
               <button class="card_button" onclick="myFunctionPad()" style="width:130px;height: 45px;font-size:15px;background:#0070ae;color:#fff;">Add to cart</button>
            </div>
        </div>
    
    

  </body>
</html>
